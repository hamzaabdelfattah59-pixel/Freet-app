export const dynamic = 'force-dynamic';

// بيتندهي مرة كل يوم من Vercel عشان Supabase المجاني ما يوقفش المشروع بعد أسبوع من غير نشاط
export async function GET() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
  try {
    const r = await fetch(`${url}/rest/v1/profiles?select=id&limit=1`, {
      headers: { apikey: key },
      cache: 'no-store',
    });
    return Response.json({ ok: r.ok, status: r.status, at: new Date().toISOString() });
  } catch (e) {
    return Response.json({ ok: false, error: String(e) }, { status: 500 });
  }
}
