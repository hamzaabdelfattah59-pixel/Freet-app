create or replace function add_member(oid uuid, uid uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from members where outing_id = oid and user_id = auth.uid()) then
    raise exception 'not a member';
  end if;
  insert into members (outing_id, user_id) values (oid, uid) on conflict do nothing;
end $$;
grant execute on function add_member(uuid, uuid) to authenticated;
